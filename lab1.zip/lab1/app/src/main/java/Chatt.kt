class Chatt(var username: String? = null,
            var message: String? = null,
            var timestamp: String? = null)